/*
  # Create PM User

  1. Changes
    - Create new team member with PM role
    - Name: Jean PM
    - Email: jean.padilla93@hotmail.com
    
  2. Security
    - Creates auth user first
    - Links team member to auth user
*/

-- Create auth user with a secure way to handle the password
INSERT INTO auth.users (
  id,
  email,
  encrypted_password,
  email_confirmed_at,
  raw_app_meta_data,
  raw_user_meta_data,
  aud,
  role,
  instance_id
) VALUES (
  gen_random_uuid(),
  'jean.padilla93@hotmail.com',
  crypt('password123', gen_salt('bf')),
  now(),
  '{"provider":"email","providers":["email"]}',
  '{}',
  'authenticated',
  'authenticated',
  '00000000-0000-0000-0000-000000000000'
);

-- Create team member linked to the auth user
INSERT INTO team_members (
  auth_id,
  name,
  email,
  role
)
SELECT 
  id as auth_id,
  'Jean PM' as name,
  'jean.padilla93@hotmail.com' as email,
  'pm' as role
FROM auth.users
WHERE email = 'jean.padilla93@hotmail.com';