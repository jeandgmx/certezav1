/*
  # Remove team_members table and dependencies

  1. Changes
    - Drop all policies that reference team_members table
    - Drop team_members table and related constraints
    - Drop team_role enum type
    - Update deliverables table to use text for created_by
*/

-- Drop policies that depend on team_members
DROP POLICY IF EXISTS "Team members can view all clients" ON clients;
DROP POLICY IF EXISTS "Team members can manage clients" ON clients;
DROP POLICY IF EXISTS "Team members can manage phases" ON phases;
DROP POLICY IF EXISTS "Team members can manage deliverables" ON deliverables;

-- Drop foreign key constraints that reference team_members
ALTER TABLE deliverables DROP CONSTRAINT IF EXISTS deliverables_created_by_fkey;

-- Drop the team_members table
DROP TABLE IF EXISTS team_members;

-- Drop the team_role enum type
DROP TYPE IF EXISTS team_role;

-- Modify deliverables table to use text for created_by
ALTER TABLE deliverables ALTER COLUMN created_by TYPE text USING created_by::text;

-- Create new simplified policies for authenticated users
CREATE POLICY "Allow authenticated users to view all clients"
  ON clients FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to manage clients"
  ON clients FOR ALL
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to manage phases"
  ON phases FOR ALL
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to manage deliverables"
  ON deliverables FOR ALL
  TO authenticated
  USING (true);