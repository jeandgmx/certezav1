/*
  # Update clients table schema

  1. Changes
    - Add project_name column to clients table
    - Add assigned_pm column to clients table
    - Add foreign key relationship between clients and team_members
    - Update RLS policies to reflect new relationships

  2. Security
    - Maintain existing RLS policies
    - Add policy for PM assignment
*/

-- Add new columns to clients table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'clients' AND column_name = 'project_name'
  ) THEN
    ALTER TABLE clients ADD COLUMN project_name text NOT NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'clients' AND column_name = 'assigned_pm'
  ) THEN
    ALTER TABLE clients ADD COLUMN assigned_pm uuid REFERENCES team_members(id);
  END IF;
END $$;

-- Create index for assigned_pm
CREATE INDEX IF NOT EXISTS idx_clients_assigned_pm ON clients(assigned_pm);

-- Update or create policies for PM assignment
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'clients' 
    AND policyname = 'PMs can view assigned clients'
  ) THEN
    CREATE POLICY "PMs can view assigned clients"
      ON clients
      FOR SELECT
      TO authenticated
      USING (
        EXISTS (
          SELECT 1 FROM team_members 
          WHERE team_members.auth_id = auth.uid()
          AND team_members.id = clients.assigned_pm
          AND team_members.role = 'pm'
        )
      );
  END IF;
END $$;