/*
  # Initial Schema for Certeza Platform

  1. New Tables
    - `clients`: Stores client information and their unique access links
    - `phases`: Defines the different phases of the client journey
    - `deliverables`: Stores all deliverables associated with each phase
    - `validations`: Tracks client validations of deliverables
    - `comments`: Stores comments on deliverables from both clients and team
    - `team_members`: Stores dgmx team member information and roles

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users based on their roles
*/

-- Create enum for team member roles
CREATE TYPE team_role AS ENUM ('pm', 'commercial', 'technical');

-- Create enum for phase status
CREATE TYPE phase_status AS ENUM ('pending', 'active', 'completed');

-- Create enum for deliverable status
CREATE TYPE deliverable_status AS ENUM ('draft', 'ready_for_review', 'validated', 'rejected');

-- Create clients table
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  company text NOT NULL,
  email text UNIQUE NOT NULL,
  access_token text NOT NULL UNIQUE DEFAULT gen_random_uuid()::text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create team_members table
CREATE TABLE IF NOT EXISTS team_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_id uuid NOT NULL REFERENCES auth.users(id),
  name text NOT NULL,
  email text UNIQUE NOT NULL,
  role team_role NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create phases table
CREATE TABLE IF NOT EXISTS phases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES clients(id),
  name text NOT NULL,
  description text,
  order_index integer NOT NULL,
  status phase_status DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(client_id, order_index)
);

-- Create deliverables table
CREATE TABLE IF NOT EXISTS deliverables (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phase_id uuid NOT NULL REFERENCES phases(id),
  title text NOT NULL,
  description text,
  content jsonb,
  status deliverable_status DEFAULT 'draft',
  created_by uuid NOT NULL REFERENCES team_members(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create validations table
CREATE TABLE IF NOT EXISTS validations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deliverable_id uuid NOT NULL REFERENCES deliverables(id),
  client_id uuid NOT NULL REFERENCES clients(id),
  validated_at timestamptz DEFAULT now(),
  UNIQUE(deliverable_id, client_id)
);

-- Create comments table
CREATE TABLE IF NOT EXISTS comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deliverable_id uuid NOT NULL REFERENCES deliverables(id),
  author_type text NOT NULL CHECK (author_type IN ('client', 'team')),
  author_id uuid NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE team_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE phases ENABLE ROW LEVEL SECURITY;
ALTER TABLE deliverables ENABLE ROW LEVEL SECURITY;
ALTER TABLE validations ENABLE ROW LEVEL SECURITY;
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;

-- Create policies for team members
CREATE POLICY "Team members can view all clients"
  ON clients FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM team_members WHERE auth_id = auth.uid()
  ));

CREATE POLICY "Team members can manage clients"
  ON clients FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM team_members WHERE auth_id = auth.uid()
  ));

CREATE POLICY "Team members can manage phases"
  ON phases FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM team_members WHERE auth_id = auth.uid()
  ));

CREATE POLICY "Team members can manage deliverables"
  ON deliverables FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM team_members WHERE auth_id = auth.uid()
  ));

-- Create policies for clients
CREATE POLICY "Clients can view their own data"
  ON clients FOR SELECT
  USING (access_token::text = current_setting('request.jwt.claims')::json->>'access_token');

CREATE POLICY "Clients can view their phases"
  ON phases FOR SELECT
  USING (client_id IN (
    SELECT id FROM clients 
    WHERE access_token::text = current_setting('request.jwt.claims')::json->>'access_token'
  ));

CREATE POLICY "Clients can view their deliverables"
  ON deliverables FOR SELECT
  USING (phase_id IN (
    SELECT p.id FROM phases p
    JOIN clients c ON c.id = p.client_id
    WHERE c.access_token::text = current_setting('request.jwt.claims')::json->>'access_token'
  ));

-- Create functions
CREATE OR REPLACE FUNCTION automatically_update_phase_status()
RETURNS TRIGGER AS $$
BEGIN
  -- If all deliverables in a phase are validated, mark the phase as completed
  IF NOT EXISTS (
    SELECT 1 FROM deliverables d
    WHERE d.phase_id = NEW.phase_id
    AND d.status != 'validated'
  ) THEN
    UPDATE phases SET status = 'completed'
    WHERE id = NEW.phase_id;
    
    -- Activate next phase if it exists
    UPDATE phases SET status = 'active'
    WHERE client_id = (
      SELECT client_id FROM phases WHERE id = NEW.phase_id
    )
    AND order_index = (
      SELECT order_index + 1 FROM phases WHERE id = NEW.phase_id
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for phase status updates
CREATE TRIGGER update_phase_status
AFTER INSERT OR UPDATE ON validations
FOR EACH ROW
EXECUTE FUNCTION automatically_update_phase_status();

-- Create indexes for better query performance
CREATE INDEX idx_phases_client_id ON phases(client_id);
CREATE INDEX idx_deliverables_phase_id ON deliverables(phase_id);
CREATE INDEX idx_validations_deliverable_id ON validations(deliverable_id);
CREATE INDEX idx_comments_deliverable_id ON comments(deliverable_id);