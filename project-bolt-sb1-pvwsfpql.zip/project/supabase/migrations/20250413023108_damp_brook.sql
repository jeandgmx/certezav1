/*
  # Create clients and phases tables with policy checks

  1. New Tables
    - `clients`: Stores client information and access tokens
      - `id`: Primary key
      - `name`: Client's name
      - `company`: Company name
      - `email`: Client's email (unique)
      - `project_name`: Name of the project
      - `access_token`: Unique token for client access
      - `created_at`: Timestamp of creation
      - `updated_at`: Timestamp of last update

    - `phases`: Stores project phases for each client
      - `id`: Primary key
      - `client_id`: Foreign key to clients table
      - `name`: Phase name
      - `description`: Phase description
      - `order_index`: Order of the phase
      - `status`: Current status (pending, active, completed)
      - `created_at`: Timestamp of creation
      - `updated_at`: Timestamp of last update

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users and clients
*/

-- Create clients table
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  company text NOT NULL,
  email text NOT NULL UNIQUE,
  project_name text NOT NULL,
  access_token text NOT NULL UNIQUE DEFAULT gen_random_uuid()::text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS for clients
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;

-- Create phases table
CREATE TABLE IF NOT EXISTS phases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES clients(id),
  name text NOT NULL,
  description text,
  order_index integer NOT NULL,
  status phase_status DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(client_id, order_index)
);

-- Enable RLS for phases
ALTER TABLE phases ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_phases_client_id ON phases(client_id);

-- Create policies for clients table with existence checks
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'clients' 
    AND policyname = 'Clients can view their own data'
  ) THEN
    CREATE POLICY "Clients can view their own data"
      ON clients
      FOR SELECT
      TO public
      USING (access_token = current_setting('request.jwt.claims')::json->>'access_token');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'clients' 
    AND policyname = 'Team members can manage clients'
  ) THEN
    CREATE POLICY "Team members can manage clients"
      ON clients
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM team_members WHERE team_members.auth_id = auth.uid()
      ));
  END IF;
END $$;

-- Create policies for phases table with existence checks
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'phases' 
    AND policyname = 'Clients can view their phases'
  ) THEN
    CREATE POLICY "Clients can view their phases"
      ON phases
      FOR SELECT
      TO public
      USING (client_id IN (
        SELECT id FROM clients
        WHERE access_token = current_setting('request.jwt.claims')::json->>'access_token'
      ));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'phases' 
    AND policyname = 'Team members can manage phases'
  ) THEN
    CREATE POLICY "Team members can manage phases"
      ON phases
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM team_members WHERE team_members.auth_id = auth.uid()
      ));
  END IF;
END $$;