/*
  # Change assigned_pm column type

  1. Changes
    - Drop policy that references the assigned_pm column
    - Drop foreign key constraint and index
    - Change assigned_pm column type from UUID to text
    - Make assigned_pm nullable

  2. Security
    - Remove PM-specific policy since we're no longer linking to team_members
*/

-- First drop the policy that depends on the column
DROP POLICY IF EXISTS "PMs can view assigned clients" ON clients;

-- Then drop the foreign key constraint and index
ALTER TABLE clients DROP CONSTRAINT IF EXISTS clients_assigned_pm_fkey;
DROP INDEX IF EXISTS idx_clients_assigned_pm;

-- Finally change the column type
ALTER TABLE clients ALTER COLUMN assigned_pm TYPE text USING assigned_pm::text;
ALTER TABLE clients ALTER COLUMN assigned_pm DROP NOT NULL;