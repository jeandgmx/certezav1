import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/types/supabase'
import type { PostgrestError } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl) {
  throw new Error('Missing env.VITE_SUPABASE_URL');
}
if (!supabaseAnonKey) {
  throw new Error('Missing env.VITE_SUPABASE_ANON_KEY');
}

// Remove any trailing slashes from the URL
const cleanUrl = supabaseUrl.replace(/\/$/, '');

export const supabase = createClient<Database>(cleanUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

// Test the connection
const testConnection = async () => {
  try {
    const { error } = await supabase
      .from('clients')
      .select('count', { count: 'exact', head: true })
      .returns<{ count: number }>();
      
    if (error) throw error;
    console.log('Successfully connected to Supabase');
  } catch (error) {
    const errorMessage = error instanceof Error 
      ? error.message 
      : (error as PostgrestError)?.message || 'Unknown error';
    
    console.error('Failed to connect to Supabase:', errorMessage);
    throw new Error(`Supabase connection failed: ${errorMessage}`);
  }
};

// Initialize connection test
testConnection();