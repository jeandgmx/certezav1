import React from 'react'
import { useState } from 'react'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { format } from 'date-fns'
import { es } from 'date-fns/locale'
import { Plus, Search, Loader2, Check, Link2 } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Checkbox } from '@/components/ui/checkbox'
import { supabase } from '@/lib/supabase'

const clientSchema = z.object({
  name: z.string().min(2, 'El nombre es requerido'),
  email: z.string().email('Correo electrónico inválido'),
  company: z.string().min(2, 'La empresa es requerida'),
  project_name: z.string().min(2, 'El nombre del proyecto es requerido'),
  phases: z.array(z.string()).min(1, 'Selecciona al menos una fase'),
})

type ClientForm = z.infer<typeof clientSchema>

interface Client {
  id: string
  name: string
  email: string
  project_name: string
  access_token: string
  created_at: string
  phases: Array<{ name: string; status: string }>
}

const phases = [
  { id: 'discovery', label: 'Discovery' },
  { id: 'demo', label: 'Demo & Validación' },
  { id: 'shape_up', label: 'Shape Up Express' },
  { id: 'proposal', label: 'Propuesta Final' },
  { id: 'mvp', label: 'MVP Operativo' },
]

export default function ClientsPage() {
  const [isOpen, setIsOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [clients, setClients] = useState<Client[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [copiedLink, setCopiedLink] = useState('')
  const { toast } = useToast()

  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm<ClientForm>({
    resolver: zodResolver(clientSchema),
  })

  const onSubmit = async (data: ClientForm) => {
    try {
      setIsLoading(true)
      const { data: client, error } = await supabase
        .from('clients')
        .insert([
          {
            name: data.name,
            email: data.email,
            company: data.company,
            project_name: data.project_name,
          },
        ])
        .select()
        .single()

      if (error) throw error

      const { error: phasesError } = await supabase.from('phases').insert(
        data.phases.map((phaseId, index) => ({
          client_id: client.id,
          name: phases.find((p) => p.id === phaseId)?.label,
          order_index: index,
          status: index === 0 ? 'active' : 'pending',
        }))
      )

      if (phasesError) throw phasesError

      toast({
        title: 'Cliente creado',
        description: 'El cliente ha sido creado exitosamente',
      })

      setIsOpen(false)
      reset()
      loadClients()
    } catch (error) {
      console.error('Error creating client:', error)
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error instanceof Error ? error.message : 'Hubo un error al crear el cliente',
      })
    } finally {
      setIsLoading(false)
    }
  }

  const loadClients = async () => {
    try {
      setIsLoading(true)
      const { data, error } = await supabase
        .from('clients')
        .select('*, phases (name, status)')
        .order('created_at', { ascending: false })
        .returns<{
          id: string;
          name: string;
          email: string;
          project_name: string;
          access_token: string;
          created_at: string;
          phases: Array<{ name: string; status: string }>;
        }[]>()

      if (error) {
        throw new Error(`Error fetching clients: ${error.message}`);
      }
      
      setClients(data || [])
    } catch (error) {
      console.error('Error loading clients:', error)
      toast({
        variant: 'destructive',
        title: 'Error loading clients',
        description: error instanceof Error ? error.message : 'Failed to load clients. Please try again.',
      })
    } finally {
      setIsLoading(false)
    }
  }

  React.useEffect(() => {
    loadClients()
  }, [])

  const copyAccessLink = (accessToken: string) => {
    const link = `${window.location.origin}/client/${accessToken}`
    navigator.clipboard.writeText(link)
    toast({
      title: "Link copiado",
      description: "El link de acceso ha sido copiado al portapapeles",
    })
    setCopiedLink(accessToken)
    setTimeout(() => setCopiedLink(''), 2000)
  }

  return (
    <div>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-[#0B1A3A]">
            Gestión de Clientes
          </h1>
          <Button onClick={() => setIsOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Nuevo Cliente
          </Button>
        </div>

        <div className="bg-[#F5F7FA] rounded-lg shadow-sm p-6">
          <div className="flex gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Buscar por nombre o proyecto..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">
                      Cliente
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">
                      Proyecto
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">
                      Fase Actual
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">
                      Fecha
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">
                      Acciones
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {clients.map((client) => (
                    <tr
                      key={client.id}
                      className="border-b border-gray-100 hover:bg-gray-50"
                    >
                      <td className="py-3 px-4">
                        <div>
                          <div className="font-medium text-gray-900">
                            {client.name}
                          </div>
                          <div className="text-sm text-gray-500">
                            {client.email}
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-gray-900">
                        {client.project_name}
                      </td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                          {client.phases?.[0]?.name}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-gray-500">
                        {format(new Date(client.created_at), 'PP', { locale: es })}
                      </td>
                      <td className="py-3 px-4">
                        <Button
                          variant={copiedLink === client.access_token ? "outline" : "secondary"}
                          size="sm"
                          className="flex items-center gap-2"
                          onClick={() => copyAccessLink(client.access_token)}
                        >
                          {copiedLink === client.access_token ? (
                            <>
                              <Check className="h-4 w-4" />
                              <span>Copiado</span>
                            </>
                          ) : (
                            <>
                              <Link2 className="h-4 w-4" />
                              <span>Copiar link</span>
                            </>
                          )}
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[480px] p-6">
          <DialogHeader>
            <DialogTitle>Nuevo Cliente</DialogTitle>
            <DialogDescription>
              Ingresa los datos del nuevo cliente para crear su espacio en la
              plataforma.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 mt-8">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nombre del cliente</Label>
                <Input
                  id="name"
                  placeholder="Nombre completo"
                  {...register('name')}
                />
                {errors.name && (
                  <p className="text-sm text-red-500">{errors.name.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Correo electrónico</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="cliente@empresa.com"
                  {...register('email')}
                />
                {errors.email && (
                  <p className="text-sm text-red-500">{errors.email.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="company">Empresa</Label>
                <Input
                  id="company"
                  placeholder="Nombre de la empresa"
                  {...register('company')}
                />
                {errors.company && (
                  <p className="text-sm text-red-500">{errors.company.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="project_name">Nombre del proyecto</Label>
                <Input
                  id="project_name"
                  placeholder="Nombre del proyecto"
                  {...register('project_name')}
                />
                {errors.project_name && (
                  <p className="text-sm text-red-500">
                    {errors.project_name.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label>Fases iniciales</Label>
                <div className="space-y-2">
                  <Controller
                    name="phases"
                    control={control}
                    defaultValue={[]}
                    render={({ field }) => (
                      <>
                        {phases.map((phase) => (
                          <div
                            key={phase.id}
                            className="flex items-center space-x-2"
                          >
                            <Checkbox
                              id={phase.id}
                              checked={field.value?.includes(phase.id)}
                              onCheckedChange={(checked) => {
                                const updatedValue = checked
                                  ? [...(field.value || []), phase.id]
                                  : field.value?.filter((value: string) => value !== phase.id) || []
                                field.onChange(updatedValue)
                              }}
                            />
                            <Label htmlFor={phase.id}>{phase.label}</Label>
                          </div>
                        ))}
                      </>
                    )}
                  />
                </div>
                {errors.phases && (
                  <p className="text-sm text-red-500">{errors.phases.message}</p>
                )}
              </div>
            </div>

            <div className="sticky bottom-0 pt-4 bg-background">
              <Button
                type="submit"
                className="w-full"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center">
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creando cliente...
                  </div>
                ) : (
                  'Crear cliente'
                )}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}