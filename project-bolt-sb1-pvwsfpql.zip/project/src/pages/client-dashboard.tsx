import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Shield, CheckCircle2, Clock, LockIcon, Brain, Lightbulb, Beaker, Shapes, Laptop, CheckSquare, Rocket, LineChart } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { supabase } from '@/lib/supabase'
import { cn } from '@/lib/utils'
import { Separator } from '@/components/ui/separator'

const milestones = [
  {
    id: 'diagnostic',
    name: 'Diagnóstico inicial',
    icon: Lightbulb,
    description: 'Evaluación profunda de necesidades y objetivos'
  },
  {
    id: 'concept',
    name: 'Prueba de concepto',
    icon: Beaker,
    description: 'Validación técnica y funcional del proyecto'
  },
  {
    id: 'shape_up',
    name: 'Shape Up',
    icon: Shapes,
    description: 'Definición detallada del alcance y estrategia'
  },
  {
    id: 'proposal',
    name: 'Propuesta tecnológica',
    icon: Laptop,
    description: 'Presentación de solución y arquitectura'
  },
  {
    id: 'decision',
    name: 'Decisión del proyecto',
    icon: CheckSquare,
    description: 'Evaluación final y compromiso de implementación'
  },
  {
    id: 'kickoff',
    name: 'Arranque del proyecto',
    icon: Rocket,
    description: 'Inicio de la implementación y desarrollo'
  },
  {
    id: 'evolution',
    name: 'Evolución continua',
    icon: LineChart,
    description: 'Mejora continua y optimización del proyecto'
  }
]

interface Phase {
  id: string
  name: string
  status: 'pending' | 'active' | 'completed'
  order_index: number
}

interface Client {
  id: string
  name: string
  project_name: string
  phases: Phase[]
  assigned_pm: string
}

export default function ClientDashboard() {
  const { accessToken } = useParams()
  const navigate = useNavigate()
  const [client, setClient] = useState<Client | null>(null)
  const [loading, setLoading] = useState(true)
  const [showWelcome, setShowWelcome] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadClientData = async () => {
      try {
        console.log('Loading client data with token:', accessToken)

        if (!accessToken) {
          throw new Error('Token de acceso no proporcionado')
        }

        const { data: clientData, error: clientError } = await supabase
          .from('clients')
          .select(`
            id,
            name,
            project_name,
            assigned_pm,
            phases (
              id,
              name,
              status,
              order_index
            )
          `)
          .eq('access_token', accessToken)
          .single()

        if (clientError) {
          console.error('Supabase error:', clientError)
          if (clientError.code === 'PGRST116') {
            throw new Error('Cliente no encontrado')
          }
          throw clientError
        }

        if (!clientData) {
          throw new Error('No se encontraron datos del cliente')
        }
        
        console.log('Client data loaded:', clientData)
        setClient(clientData)
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Error al cargar los datos'
        console.error('Error loading client data:', errorMessage)
        setError(errorMessage)
        // Only redirect if the component is still mounted
        const timer = setTimeout(() => navigate('/login'), 3000)
        return () => clearTimeout(timer)
      } finally {
        setLoading(false)
        // Hide welcome screen after 2 seconds
        const timer = setTimeout(() => setShowWelcome(false), 2000)
        return () => clearTimeout(timer)
      }
    }
    
    loadClientData()
  }, [accessToken, navigate])

  if (loading || showWelcome) {
    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="min-h-screen bg-gradient-to-br from-[#0B1A3A] to-[#0055FF] flex items-center justify-center"
      >
        <div className="text-center text-white">
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Brain className="h-24 w-24 mx-auto mb-6 text-[#00D084]" />
          </motion.div>
          <motion.h1
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-3xl font-bold mb-4"
          >
            ¿Estás listo para diseñar el futuro de tu proyecto?
          </motion.h1>
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className="w-64 h-1 bg-[#00D084] mx-auto rounded-full"
          />
        </div>
      </motion.div>
    )
  }

  if (error || !client) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0B1A3A] to-[#0055FF] flex items-center justify-center">
        <div className="text-center text-white">
          <Shield className="h-16 w-16 mx-auto mb-4 text-[#00D084]" />
          <h1 className="text-2xl font-bold mb-2">Link no válido o expirado</h1>
          <p className="text-gray-300 mb-4">
            {error || 'Por favor, contacta a tu PM para obtener un nuevo acceso.'}
          </p>
          <p className="text-sm text-gray-400">Redirigiendo al inicio en unos segundos...</p>
        </div>
      </div>
    )
  }

  const sortedPhases = [...client.phases].sort((a, b) => a.order_index - b.order_index)
  const currentPhase = sortedPhases.find(phase => phase.status === 'active')
  const completedPhases = sortedPhases.filter(phase => phase.status === 'completed').length
  const progress = (completedPhases / sortedPhases.length) * 100

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="min-h-screen bg-gradient-to-br from-[#0B1A3A] via-[#0B1A3A] to-[#0044CC] pb-20"
      >
        {/* Header */}
        <motion.header
          className="container mx-auto px-4 py-4 sm:py-8"
        >
          {/* Welcome Section */}
          <motion.div 
            className="bg-white/10 backdrop-blur-lg rounded-2xl p-4 sm:p-8 text-white mb-4"
            whileHover={{ scale: 1.01 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6 mb-6">
              <Shield className="h-12 w-12 sm:h-16 sm:w-16 text-[#00D084]" />
              <div>
                <motion.h1
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  className="text-2xl sm:text-4xl font-bold mb-2 text-center sm:text-left"
                >
                  Bienvenido a tu espacio estratégico, {client.name}
                </motion.h1>
                <motion.p
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="text-base sm:text-xl text-gray-300 text-center sm:text-left"
                >
                  Este es tu espacio estratégico donde podrás visualizar tu avance, revisar entregables y tomar decisiones con confianza
                </motion.p>
              </div>
            </div>
          </motion.div>
        </motion.header>

        <main className="container mx-auto px-4">
          {/* Milestone Progress Bar */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="bg-white/10 backdrop-blur-lg rounded-2xl p-4 sm:p-8 text-white border border-white/10 mb-8"
          >
            <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-8">Ruta hacia la certeza</h2>
            
            <div className="relative">
              {/* Progress Line */}
              <div className="absolute top-6 left-6 right-6 h-2 bg-white/20 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 1.5, ease: "easeInOut" }}
                  className="relative h-full"
                >
                  <div className="absolute inset-0 bg-[#00D084]" />
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: [0.2, 0.4, 0.2] }}
                    transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                    className="absolute inset-0 bg-white/30"
                  />
                </motion.div>
              </div>

              {/* Milestones */}
              <div className="hidden sm:grid grid-cols-7 gap-4">
                {milestones.map((milestone, index) => (
                  <div
                    key={milestone.id}
                    className="relative pt-12 text-center group"
                  >
                    <motion.div
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ delay: index * 0.1 }}
                      className="relative"
                    >
                      {/* Milestone Icon */}
                      <div
                        className={cn(
                          "w-12 h-12 mx-auto rounded-full flex items-center justify-center transition-colors",
                          index <= completedPhases
                            ? "bg-[#00D084] ring-4 ring-[#00D084]/20"
                            : index === completedPhases + 1
                            ? "bg-[#0055FF] ring-4 ring-[#0055FF]/20 animate-pulse"
                            : "bg-white/20"
                        )}
                      >
                        {index <= completedPhases ? (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{ type: "spring", stiffness: 200, damping: 10 }}
                          >
                            <CheckCircle2 className="w-6 h-6" />
                          </motion.div>
                        ) : (
                          <milestone.icon className="w-6 h-6" />
                        )}
                      </div>

                      {/* Milestone Name */}
                      <h3 className="mt-3 text-sm font-medium">
                        {milestone.name}
                      </h3>

                      {/* Tooltip */}
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2 bg-white text-gray-900 rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                        <p className="text-xs">{milestone.description}</p>
                      </div>
                    </motion.div>
                  </div>
                ))}
              </div>
              
              {/* Mobile Milestones */}
              <div className="sm:hidden">
                <div className="flex overflow-x-auto pb-4 space-x-6 snap-x">
                  {milestones.map((milestone, index) => (
                    <div
                      key={milestone.id}
                      className="flex-none w-32 snap-center"
                    >
                      <motion.div
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ delay: index * 0.1 }}
                        className="relative text-center"
                      >
                        <div
                          className={cn(
                            "w-12 h-12 mx-auto rounded-full flex items-center justify-center transition-colors",
                            index <= completedPhases
                              ? "bg-[#00D084] ring-4 ring-[#00D084]/20"
                              : index === completedPhases + 1
                              ? "bg-[#0055FF] ring-4 ring-[#0055FF]/20 animate-pulse"
                              : "bg-white/20"
                          )}
                        >
                          {index <= completedPhases ? (
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ type: "spring", stiffness: 200, damping: 10 }}
                            >
                              <CheckCircle2 className="w-6 h-6" />
                            </motion.div>
                          ) : (
                            <milestone.icon className="w-6 h-6" />
                          )}
                        </div>
                        <h3 className="mt-2 text-sm font-medium">
                          {milestone.name}
                        </h3>
                      </motion.div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Phase Details */}
            <Separator className="my-8" />
            
            <div className="space-y-6">
              <h3 className="text-xl font-semibold">Detalle de etapas</h3>
              {sortedPhases.map((phase, index) => (
                <motion.div
                  key={phase.id}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                >
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-6">
                    <motion.div
                      whileHover={{ scale: 1.1 }}
                      className={cn(
                        "w-12 h-12 rounded-xl flex items-center justify-center",
                        phase.status === 'completed'
                          ? "bg-[#00D084]"
                          : phase.status === 'active'
                          ? "bg-[#0055FF]"
                          : "bg-white/20"
                      )}
                    >
                      {phase.status === 'completed' && <CheckCircle2 className="h-6 w-6" />}
                      {phase.status === 'active' && <Clock className="h-6 w-6" />}
                      {phase.status === 'pending' && <LockIcon className="h-6 w-6" />}
                    </motion.div>
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold">
                        {phase.name}
                      </h3>
                      <p className="text-sm sm:text-base text-gray-300">
                        {phase.status === 'completed' && "✨ Etapa completada"}
                        {phase.status === 'active' && "🎯 Etapa en curso"}
                        {phase.status === 'pending' && "🔒 Etapa bloqueada"}
                      </p>
                    </div>
                    {phase.status === 'active' && (
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg"
                      >
                        Ver detalles
                      </motion.button>
                    )}
                  </div>
                  {index < sortedPhases.length - 1 && (
                    <div className="ml-6 my-4 border-l-2 border-white/10 h-8" />
                  )}
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Current Phase */}
          {currentPhase && (
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="bg-white/10 backdrop-blur-lg rounded-2xl p-4 sm:p-8 mb-8 text-white border border-white/10"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl sm:text-2xl font-bold mb-2">
                    Tu etapa actual: {currentPhase.name}
                  </h2>
                  <p className="text-sm sm:text-base text-gray-300">
                    Completa esta etapa para avanzar en tu journey digital.
                  </p>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-full sm:w-auto px-6 py-3 bg-[#00D084] hover:bg-[#00C077] text-white rounded-xl font-semibold shadow-lg text-center"
                >
                  Revisar entregables
                </motion.button>
              </div>
            </motion.div>
          )}
        </main>

        {/* Floating Chat Button */}
        <motion.div 
          className="fixed bottom-4 sm:bottom-6 right-4 sm:right-6 group"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 1 }}
        >
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileHover={{ opacity: 1, y: 0 }}
            className="hidden sm:block absolute bottom-full right-0 mb-4 p-3 bg-white rounded-xl shadow-lg w-64"
          >
            <p className="text-sm text-gray-600">
              ¿Tienes dudas sobre tu journey? ¡Estoy aquí para ayudarte! 🤖
            </p>
          </motion.div>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="h-14 w-14 bg-[#00D084] hover:bg-[#00C077] rounded-full flex items-center justify-center text-white shadow-lg"
          >
            <Brain className="h-6 w-6" />
          </motion.button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}