import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import LoginPage from './pages/login'
import ClientsPage from './pages/clients'
import ClientDashboard from './pages/client-dashboard'
import { AuthenticatedLayout } from './components/layout/authenticated-layout'
import { Toaster } from './components/ui/toaster'
import { useEffect } from 'react'

function App() {
  useEffect(() => {
    // Log current path to help with debugging
    console.log('Current path:', window.location.pathname)
  }, [])

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route
          path="/dashboard-dgmx"
          element={
            <AuthenticatedLayout>
              <ClientsPage />
            </AuthenticatedLayout>
          }
        />
        <Route path="/client/:accessToken" element={<ClientDashboard />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
        <Route path="/" element={<Navigate to="/login" replace />} />
      </Routes>
      <Toaster />
    </Router>
  )
}

export default App